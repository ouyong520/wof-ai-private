﻿Training Farm R0.4.7 Windows 便携实机证明包

来源 candidate: ba1fc43c2ea2a5f04909a1b3dca88b69845d62c8

1. 解压到普通本地目录；中文、空格、括号路径均支持。
2. 可先双击“验证便携包.cmd”做 ROM-free 完整性校验。
3. 双击“开始三国10训实机验证.cmd”。
4. R0.4.6 会检测 Python 3.10..3.14、准备同级专用环境，并进入既有 Owner WOF ZIP 选择流程。
5. 只选择你合法持有、且位于本便携包之外的本地 WOF ZIP。
6. evidence 默认在便携包同级“三国10训-data\evidence”。
7. 只有 strict runner 明确的 R0.2 REAL_WOF PASS + R0.4 REAL_WOF_FORK PASS 才是实机证明。

本包不包含、不下载、不复制 ROM/BIOS/game assets；realWofProof=false；R0.5 未授权；portable 层不修改 proof acceptance 语义。
