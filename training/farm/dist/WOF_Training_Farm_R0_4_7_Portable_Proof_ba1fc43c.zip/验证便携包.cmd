﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul 2>nul
set "ROOT=%~dp0"
set "PY="
for %%V in (3.14 3.13 3.12 3.11 3.10) do if not defined PY (py -%%V -c "import sys; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<=(3,14) else 1)" >nul 2>nul && set "PY=py -%%V")
if not defined PY (python -c "import sys; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<=(3,14) else 1)" >nul 2>nul && set "PY=python")
if not defined PY (echo WAITING_PREREQUISITE - 需要 Python 3.10..3.14 才能执行便携包校验。& if "%WOF_PORTABLE_NO_PAUSE%"=="" pause& exit /b 2)
pushd "%ROOT%payload"
%PY% -m training.farm.windows_portable_real_wof_bundle_verifier --bundle-root "%ROOT%"
set "RC=%ERRORLEVEL%"
popd
if "%WOF_PORTABLE_NO_PAUSE%"=="" pause
exit /b %RC%
