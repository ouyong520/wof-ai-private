﻿@echo off
setlocal
call "%~dp0开始三国10训实机验证.cmd" %*
exit /b %ERRORLEVEL%
