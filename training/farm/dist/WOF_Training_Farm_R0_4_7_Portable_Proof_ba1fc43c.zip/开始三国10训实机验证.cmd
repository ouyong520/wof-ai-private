﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul 2>nul
set "BUNDLE_ROOT=%~dp0"
for %%I in ("%BUNDLE_ROOT%..") do set "LOCAL_ROOT=%%~fI\三国10训-data"
if not "%WOF_TRAINING_FARM_LOCAL_ROOT%"=="" set "LOCAL_ROOT=%WOF_TRAINING_FARM_LOCAL_ROOT%"
set "WOF_TRAINING_FARM_LOCAL_ROOT=%LOCAL_ROOT%"
set "WOF_BOOTSTRAP_NO_PAUSE=1"
call "%BUNDLE_ROOT%payload\training\farm\run_windows_oneclick_env_bootstrap.cmd" --local-root "%LOCAL_ROOT%" --evidence-root "%LOCAL_ROOT%\evidence" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo [Training Farm] 命令完成。真实 R0.2/R0.4 是否 PASS 只以 strict runner 输出为准。) else (echo [Training Farm] 返回码 %RC%。请保留 WAITING_PREREQUISITE / BLOCKED 详情。)
if "%WOF_PORTABLE_NO_PAUSE%"=="" pause
exit /b %RC%
